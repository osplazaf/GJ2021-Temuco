﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class CambiarEscena : MonoBehaviour
{
   public void CargarEscena( string nombreEscena)
   {
        SceneManager.LoadScene(nombreEscena);
   }

}