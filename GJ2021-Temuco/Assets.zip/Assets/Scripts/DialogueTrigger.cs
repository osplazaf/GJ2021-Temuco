﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueTrigger : MonoBehaviour
{
    public Dialogo dialogo;

    public void TriggerDialogue ()
    {
        FindObjectOfType<DialogueManager>().IniciarDialogo(dialogo);
    }
}
